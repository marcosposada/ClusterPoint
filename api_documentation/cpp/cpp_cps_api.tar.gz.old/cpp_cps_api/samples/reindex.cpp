#include "cps/CPS_API.hpp"

#include <iostream>
#include <string>
#include <vector>
#include <map>

int main() {
    try
    {
        CPS::Connection *conn = new CPS::Connection("tcp://127.0.0.1:5550", "storage", "user", "password");

        CPS::Response *resp = conn->sendRequest<CPS::Response>(CPS::Request("reindex"));

        std::cout << "Reindex initialized in: " << resp->getSeconds() << std::endl;

        // Clean Up
        delete resp;
        delete conn;
    }
    catch (CPS::Exception&  e)
    {
        std::cerr << e.what() << endl;
        std::cerr << boost::diagnostic_information(e);
    }

    return 0;
}
