﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace CPS
{
    /// <summary>
    /// CPS Exception class, that can be thrown in various cases.
    /// </summary>
    public class CPS_Exception : System.Exception
    {
        /// <summary>
        /// Creates new CPS_Exception class instance.
        /// </summary>
        public CPS_Exception()
            : base()
        {
            this.p_code = ERROR_CODE.OK;
        }

        /// <summary>
        /// Creates new CPS_Exception class instance.
        /// </summary>
        /// <param name="message">Exception message.</param>
        public CPS_Exception(string message)
            : base(message)
        {
            this.p_code = ERROR_CODE.OK;
        }

        /// <summary>
        /// Creates new CPS_Exception class instance.
        /// </summary>
        /// <param name="message">Exception message.</param>
        /// <param name="inner">Another exception.</param>
        public CPS_Exception(string message, System.Exception inner)
            : base(message, inner)
        {
            this.p_code = ERROR_CODE.OK;
        }

        /// <summary>
        /// Creates new CPS_Exception class instance. Constructor not available for user.
        /// </summary>
        /// <param name="info">Serialization information.</param>
        /// <param name="context">Streaming context.</param>
        protected CPS_Exception(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
            : base(info, context)
        {
            this.p_code = ERROR_CODE.OK;
        }

        /// <summary>
        /// Converts CPS_Exception to string message.
        /// </summary>
        /// <returns>String message.</returns>
        public override string ToString()
        {
            if (this.p_code != 0)
                return "[" + (ushort)(this.p_code) + "]: " + this.Message;
            else
                return this.Message;
        }

        /// <summary>
        /// Sets CPS_Exception error code
        /// </summary>
        /// <param name="code">Error code</param>
        /// <returns>Self (CPS_Exception).</returns>
        public CPS_Exception SetCode(ERROR_CODE code)
        {
            this.p_code = code;
            return this;
        }

        /// <summary>
        /// Error code.
        /// </summary>
        private ERROR_CODE p_code;

        /// <summary>
        /// Various error codes.
        /// </summary>
        public enum ERROR_CODE
        {
            /// <summary>
            /// OK, no error - 0.
            /// </summary>
            OK = 0,
            /// <summary>
            /// Invalid response - 9001.
            /// </summary>
            INVALID_RESPONSE = 9001,
            /// <summary>
            /// Invalid parameter - 9002.
            /// </summary>
            INVALID_PARAMETER = 9002,
            /// <summary>
            /// Invalid xpath(s) - 9003.
            /// </summary>
            INVALID_XPATHS = 9003,
            /// <summary>
            /// Invalid connection string - 9004.
            /// </summary>
            INVALID_CONNECTION_STRING = 9004,
            /// <summary>
            /// Protobuf-related error - 9005.
            /// </summary>
            PROTOBUF_ERROR = 9005,
            /// <summary>
            /// Socket-related error - 9006.
            /// </summary>
            SOCKET_ERROR = 9006,
            /// <summary>
            /// Timeout - 9007.
            /// </summary>
            TIMEOUT = 9007
        }
    }

    /// <summary>
    /// CPS Connection class, that represents connection to CPS storage.
    /// </summary>
    public class CPS_Connection
    {
        /// <summary>
        /// Creates new CPS Connection class instance. Note. Constructor does not connect to storage.
        /// </summary>
        /// <param name="connectionString">Connection string or URL. .NET API supports tcp://... and http://... protocols.</param>
        /// <param name="storageName">Storage new you want to connect to.</param>
        /// <param name="username">Username for storage.</param>
        /// <param name="password">Password for storage.</param>
        /// <param name="documentRootXpath">Document root tag name, for example 'document'.</param>
        /// <param name="documentIdXpath">Document ID xpath, for example '//document/id'.</param>
        public CPS_Connection(string connectionString, string storageName, string username, string password, string documentRootXpath = "document", string documentIdXpath = "//document/id")
        {
            this.p_storageName = storageName;
            this.p_username = username;
            this.p_password = password;
            this.p_documentRootXpath = documentRootXpath;
            this.p_documentIdXpath = new List<string>();
            string[] xid = documentIdXpath.Split('/');
            int i = 0;
            for (i = 0; i < xid.Length; i++)
                if (xid[i].Length > 0)
                    this.p_documentIdXpath.Add(xid[i]);
            try
            {
                this.p_connectionString = new Uri(connectionString);
            }
            catch (Exception)
            {
                throw new CPS_Exception("Invalid connection string").SetCode(CPS_Exception.ERROR_CODE.INVALID_CONNECTION_STRING);
            }

            if (this.p_connectionString.Scheme.ToLower() != "http" && this.p_connectionString.Scheme.ToLower() != "tcp")
                throw new CPS_Exception("Invalid connection string").SetCode(CPS_Exception.ERROR_CODE.INVALID_CONNECTION_STRING);

            if (this.p_connectionString.Host.Length <= 0)
                throw new CPS_Exception("Invalid connection string").SetCode(CPS_Exception.ERROR_CODE.INVALID_CONNECTION_STRING);

            this.p_applicationId = "CPS_dotNET_API";
            this.p_debug = false;
        }

        /// <summary>
        /// Sends request to Clusterpoint Server. Returned CPS_Response should be casted to command-specific response class.
        /// </summary>
        /// <param name="request">Request to send.</param>
        /// <returns>Command-specific CPS_Response object instance.</returns>
        public CPS_Response sendRequest(CPS_Request request)
        {
            string requestXml = this.renderRequest(request);
            byte[] requestBytes = Encoding.UTF8.GetBytes(requestXml);

            if (this.p_debug)
            {
                FileStream fs = new FileStream("request.xml", FileMode.Create);
                fs.Write(requestBytes, 0, requestBytes.Length);
                fs.Close();
            }

            string rawResponse = "";

            if (this.p_connectionString.Scheme.ToLower() == "http")
            {
                HttpWebRequest webreq = (HttpWebRequest)HttpWebRequest.Create(this.p_connectionString.OriginalString);
                webreq.UserAgent = this.p_applicationId;
                webreq.Method = "POST";
                webreq.ContentType = "application/x-www-form-urlencoded";
                webreq.ContentLength = requestBytes.Length;
                webreq.Headers["Recipient"] = this.p_storageName;
                webreq.Proxy = null;

                Stream webreq_data = webreq.GetRequestStream();
                webreq_data.Write(requestBytes, 0, requestBytes.Length);
                webreq_data.Close();

                HttpWebResponse webrsp = (HttpWebResponse)webreq.GetResponse();
                Stream webrsp_data = webrsp.GetResponseStream();
                StreamReader webrsp_reader = new StreamReader(webrsp_data);

                rawResponse = webrsp_reader.ReadToEnd();
                webrsp_reader.Close();
            }

            if (this.p_connectionString.Scheme.ToLower() == "tcp")
            {
                int port = this.p_connectionString.Port;
                if (port == 0)
                    port = 5550;
                TcpClient tcp = new TcpClient(this.p_connectionString.Host, port);
                NetworkStream net = tcp.GetStream();

                Protobuf pb = new Protobuf();
                pb.CreateField(1, Protobuf.WireType.LengthDelimited, requestBytes);
                pb.CreateStringField(2, this.p_storageName);

                MemoryStream ms = new MemoryStream();
                Protobuf_Streamer pbs = new Protobuf_Streamer(ms);
                pb.WriteToStream(pbs);

                byte[] header = CPS_Length2Header((int)(ms.Length));

                net.Write(header, 0, 8);
                net.Write(ms.GetBuffer(), 0, (int)(ms.Length));
                net.Flush();

                net.Read(header, 0, 8);
                int len = CPS_Header2Length(header);
                byte[] recv = new byte[len];
                int got = 0;
                while (got < len)
                {
                    int br = net.Read(recv, got, len - got);
                    if (br == 0)
                        throw new CPS_Exception("Server unexpectedly closed connection").SetCode(CPS_Exception.ERROR_CODE.SOCKET_ERROR);
                    got += br;
                }
                net.Close();

                ms = new MemoryStream(recv);
                pbs = new Protobuf_Streamer(ms);
                pb = new Protobuf(pbs);

                rawResponse = pb.GetStringField(1);
            }

            if (this.p_debug)
            {
                FileStream fs = new FileStream("response.xml", FileMode.Create);
                byte[] responseBytes = Encoding.UTF8.GetBytes(rawResponse);
                fs.Write(responseBytes, 0, responseBytes.Length);
                fs.Close();
            }

            switch (request.getCommand())
            {
                case "search":
                case "similar":
                    return new CPS_SearchResponse(this, request, rawResponse);
                case "update":
                case "delete":
                case "replace":
                case "partial-replace":
                case "insert":
                    return new CPS_ModifyResponse(this, request, rawResponse);
                case "alternatives":
                    return new CPS_AlternativesResponse(this, request, rawResponse);
                case "list-words":
                    return new CPS_ListWordsResponse(this, request, rawResponse);
                case "status":
                    return new CPS_StatusResponse(this, request, rawResponse);
                case "retrieve":
                case "list-last":
                case "list-first":
                case "retrieve-last":
                case "retrive-first":
                case "lookup":
                //case "similar":
                    return new CPS_LookupResponse(this, request, rawResponse);
                case "search-delete":
                    return new CPS_SearchDeleteResponse(this, request, rawResponse);
                case "list-paths":
                    return new CPS_ListPathsResponse(this, request, rawResponse);
                case "list-facets":
                    return new CPS_ListFacetsResponse(this, request, rawResponse);
                default:
                    return new CPS_Response(this, request, rawResponse);
            }
        }

        /// <summary>
        /// Sets new application ID or name to use in requests. This can be usefull to identify requests in log file.
        /// </summary>
        /// <param name="applicationId">Application ID or name.</param>
        public void setApplicationId(string applicationId)
        {
            this.p_applicationId = applicationId;
        }

        /// <summary>
        /// Enables or disables debug mode.
        /// </summary>
        /// <param name="debugMode">True or False to enable or disable debug mode.</param>
        public void setDebug(bool debugMode)
        {
            this.p_debug = debugMode;
        }

        /// <summary>
        /// Gets document root tag name.
        /// </summary>
        /// <returns>Tag name string.</returns>
        public string getDocumentRootXpath()
        {
            return this.p_documentRootXpath;
        }

        /// <summary>
        /// Gets parsed document ID xpath.
        /// </summary>
        /// <returns>List of strings with tag names.</returns>
        public List<string> getDocumentIdXpath()
        {
            return this.p_documentIdXpath;
        }

        /// <summary>
        /// Renders request XML for sending to storage.
        /// </summary>
        /// <param name="request">Request instance to render.</param>
        /// <returns>XML request as string.</returns>
        private string renderRequest(CPS_Request request)
        {
            Dictionary<string, string> envelopeFields = new Dictionary<string, string>();
            envelopeFields["storage"] = this.p_storageName;
            envelopeFields["user"] = this.p_username;
            envelopeFields["password"] = this.p_password;
            envelopeFields["command"] = request.getCommand();

            if (request.getRequestId().Length > 0)
                envelopeFields["requestid"] = request.getRequestId();
            if (this.p_applicationId.Length > 0)
                envelopeFields["application"] = this.p_applicationId;
            if (request.getRequestType().Length > 0)
                envelopeFields["type"] = request.getRequestType();

            return request.getRequestXML(this.p_documentRootXpath, this.p_documentIdXpath, envelopeFields);
        }

        /// <summary>
        /// Generates byte array with CPS TCP header.
        /// </summary>
        /// <param name="length">Request length.</param>
        /// <returns>Header as 8 byte array.</returns>
        private byte[] CPS_Length2Header(int length)
        {
            byte[] ret = new byte[8];
            ret[0] = 0x09;
            ret[1] = 0x09;
            ret[2] = 0x00;
            ret[3] = 0x00;
            ret[4] = (byte)((length & 0x000000FF));
            ret[5] = (byte)((length & 0x0000FF00) >> 8);
            ret[6] = (byte)((length & 0x00FF0000) >> 16);
            ret[7] = (byte)((length & 0xFF000000) >> 24);
            return ret;
        }

        /// <summary>
        /// Extracts response length from received header.
        /// </summary>
        /// <param name="data">8 byte long header.</param>
        /// <returns>Response length.</returns>
        private int CPS_Header2Length(byte[] data)
        {
            if (data.Length >= 8)
            {
                int int4 = data[4], int5 = data[5], int6 = data[6], int7 = data[7];
                return int4 | int5 << 8 | int6 << 16 | int7 << 24;
            }
            else
                return 0;
        }

        /// <summary>
        /// Connection string.
        /// </summary>
        private Uri p_connectionString;
        /// <summary>
        /// Storage name.
        /// </summary>
        private string p_storageName;
        /// <summary>
        /// User name.
        /// </summary>
        private string p_username;
        /// <summary>
        /// Password.
        /// </summary>
        private string p_password;
        /// <summary>
        /// Document root tag name.
        /// </summary>
        private string p_documentRootXpath;
        /// <summary>
        /// Parsed document ID xpath.
        /// </summary>
        private List<string> p_documentIdXpath;
        /// <summary>
        /// Application ID or name.
        /// </summary>
        private string p_applicationId;
        /// <summary>
        /// Debug mode.
        /// </summary>
        private bool p_debug;
    }

    /// <summary>
    /// CPS Request class defines single request for CPS storage.
    /// </summary>
    public class CPS_Request
    {
        /// <summary>
        /// Creates new CPS Request class instance.
        /// </summary>
        /// <param name="command">API command for this request.</param>
        /// <param name="requestId">Request ID to identify it in log files.</param>
        public CPS_Request(string command, string requestId = "")
        {
            this.p_command = command;
            this.p_requestId = requestId;
            this.p_requestType = "";
            this.p_textParams = new Dictionary<string, List<string>>();
            this.p_rawParams = new Dictionary<string, List<string>>();
            this.p_documents = null;// new Dictionary<string, string>();
            this.p_requestDom = null;
        }

        /// <summary>
        /// Converts current request to XML string.
        /// </summary>
        /// <param name="docRootXpath">Document root tag name.</param>
        /// <param name="docIdXpath">Parsed document ID xpath.</param>
        /// <param name="envelopeParams">Additional CPS envelope parameters.</param>
        /// <returns>Request as XML string.</returns>
        public string getRequestXML(string docRootXpath, List<string> docIdXpath, Dictionary<string, string> envelopeParams)
        {
            this.p_requestDom = new XmlDocument();
            this.p_requestDom.AppendChild(this.p_requestDom.CreateXmlDeclaration("1.0", "utf-8", "yes"));
            XmlElement root = this.p_requestDom.CreateElement("cps:request", "www.clusterpoint.com");
            this.p_requestDom.AppendChild(root);

            foreach (KeyValuePair<string, string> param in envelopeParams)
            {
                root.AppendChild(this.p_requestDom.CreateElement("cps:" + param.Key, "www.clusterpoint.com")).InnerXml = param.Value;
            }

            XmlElement contentTag = (XmlElement)root.AppendChild(this.p_requestDom.CreateElement("cps:content", "www.clusterpoint.com"));

            foreach (KeyValuePair<string, List<string>> param in this.p_textParams)
            {
                foreach (string param_value in param.Value)
                    contentTag.AppendChild(this.p_requestDom.CreateElement(param.Key)).InnerXml = param_value;
            }

            foreach (KeyValuePair<string, List<string>> param in this.p_rawParams)
            {
                foreach (string param_value in param.Value)
                {
                    XmlElement tag = this.p_requestDom.CreateElement(param.Key);
                    XmlDocumentFragment fragment = this.p_requestDom.CreateDocumentFragment();
                    fragment.InnerXml = param_value;
                    tag.AppendChild(fragment);
                    contentTag.AppendChild(tag);
                }
            }

            if (this.p_documents != null)
                foreach (KeyValuePair<string, XmlElement> pair in this.p_documents)
                {
                    int i = 0;
                    XmlElement xid = null;

                    if (pair.Value == null)
                    {
                        xid = contentTag;

                        for (i = 0; i < docIdXpath.Count; i++)
                            xid = (XmlElement)(xid.AppendChild(xid.OwnerDocument.CreateElement(docIdXpath[i])));

                        xid.AppendChild(xid.OwnerDocument.CreateTextNode(pair.Key));

                        continue;
                    }

                    XmlElement xdoc = (XmlElement)(contentTag.AppendChild(contentTag.OwnerDocument.ImportNode(pair.Value, true)));
                    xid = xdoc;
                    for (i = 1; i < docIdXpath.Count; i++)
                    {
                        XmlElement xchild = xid[docIdXpath[i]];
                        if (xchild == null)
                            xchild = (XmlElement)(xid.AppendChild(xid.OwnerDocument.CreateElement(docIdXpath[i])));

                        if (i + 1 == docIdXpath.Count)
                            if (xchild.InnerXml != pair.Key)
                                xchild.AppendChild(xchild.OwnerDocument.CreateTextNode(pair.Key));

                        xid = xchild;
                    }
                }

            return this.p_requestDom.OuterXml;
        }

        /// <summary>
        /// Gets current command.
        /// </summary>
        /// <returns>Command name.</returns>
        public string getCommand()
        {
            return this.p_command;
        }

        /// <summary>
        /// Sets request parameter as single string value.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <param name="value">Parameter value.</param>
        public void setParam(string name, string value)
        {
            if (Array.Exists<string>(CPS_Request.p_textParamNames, pn => pn == name))
                this.setTextParam(name, value);
            else if (Array.Exists<string>(CPS_Request.p_rawParamNames, pn => pn == name))
                this.setRawParam(name, value);
            else
            {
                // PHP throws exception, should we do the same?
            }
        }

        /// <summary>
        /// Sets request parameter as multiple string values.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <param name="value">List of parameter values.</param>
        public void setParam(string name, List<string> value)
        {
            if (Array.Exists<string>(CPS_Request.p_textParamNames, pn => pn == name))
                this.setTextParam(name, value);
            else if (Array.Exists<string>(CPS_Request.p_rawParamNames, pn => pn == name))
                this.setRawParam(name, value);
            else
            {
                // PHP throws exception, should we do the same?
            }
        }

        /// <summary>
        /// Gets current request ID.
        /// </summary>
        /// <returns>Request ID.</returns>
        public string getRequestId()
        {
            return this.p_requestId;
        }

        /// <summary>
        /// Sets current request ID.
        /// </summary>
        /// <param name="requestId">Request ID.</param>
        public void setRequestId(string requestId)
        {
            this.p_requestId = requestId;
        }

        /// <summary>
        /// Gets current request type.
        /// </summary>
        /// <returns>Request type.</returns>
        public string getRequestType()
        {
            return this.p_requestType;
        }

        /// <summary>
        /// Sets current request type. Do not do this unless 100% sure what you are doing!
        /// </summary>
        /// <param name="requestType">Request type.</param>
        public void setRequestType(string requestType)
        {
            this.p_requestType = requestType;
        }

        /// <summary>
        /// Sets documents for this request.
        /// Currently supported types are:
        /// * Dictionary&lt;string, CPS_SimpleXML&gt;;
        /// * Dictionary&lt;string, XmlElement&gt;;
        /// * List&lt;string&gt;.
        /// </summary>
        /// <param name="documents">Documents.</param>
        protected void setRawDocuments(Object documents)
        {
            try
            {
                Dictionary<string, XmlElement> documents_type1 = (Dictionary<string, XmlElement>)documents;
                if (documents_type1 != null)
                {
                    this.p_documents = documents_type1;
                    return;
                }
            }
            catch (Exception)
            {
                // do nothing
            }

            try
            {
                Dictionary<string, CPS_SimpleXML> documents_type2 = (Dictionary<string, CPS_SimpleXML>)documents;
                if (documents_type2 != null)
                {
                    this.p_documents = new Dictionary<string, XmlElement>();
                    foreach (KeyValuePair<string, CPS_SimpleXML> pair in documents_type2)
                        this.p_documents[pair.Key] = pair.Value.ConvertToXML();
                    return;
                }
            }
            catch (Exception)
            {
                // do nothing
            }

            try
            {
                Dictionary<string, Object> documents_type3 = (Dictionary<string, Object>)documents;
                if (documents_type3 != null)
                {
                    this.p_documents = new Dictionary<string, XmlElement>();
                    foreach (KeyValuePair<string, Object> pair in documents_type3)
                    {
                        try
                        {
                            XmlElement xval = (XmlElement)(pair.Value);
                            if (xval != null)
                            {
                                this.p_documents[pair.Key] = xval;
                                continue;
                            }
                        }
                        catch (Exception)
                        {
                            // do nothing
                        }

                        try
                        {
                            CPS_SimpleXML sval = (CPS_SimpleXML)(pair.Value);
                            if (sval != null)
                            {
                                this.p_documents[pair.Key] = sval.ConvertToXML();
                                continue;
                            }
                        }
                        catch (Exception)
                        {
                            // do nothing
                        }

                        throw new CPS_Exception("Invalid passed document dictionary element type");
                    }
                    return;
                }
            }
            catch (Exception)
            {
                // do nothing
            }

            try
            {
                List<string> documents_type4 = (List<string>)documents;
                if (documents_type4 != null)
                {
                    this.p_documents = new Dictionary<string, XmlElement>();
                    foreach (string docid in documents_type4)
                        this.p_documents[docid] = null;
                    return;
                }
            }
            catch (Exception)
            {
                // do nothing
            }

            throw new CPS_Exception("Invalid passed document type");
        }

        /// <summary>
        /// Sets text request parameter as single value.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <param name="value">Parameter value.</param>
        private void setTextParam(string name, string value)
        {
            List<string> value_array = new List<string>();
            value_array.Add(value);
            this.setTextParam(name, value_array);
        }

        /// <summary>
        /// Sets text request parameter as multiple values.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <param name="value">List of parameter values.</param>
        private void setTextParam(string name, List<string> value)
        {
            this.p_textParams[name] = value;
        }

        /// <summary>
        /// Sets raw request parameter as single value.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <param name="value">Parameter value.</param>
        private void setRawParam(string name, string value)
        {
            List<string> value_array = new List<string>();
            value_array.Add(value);
            this.setRawParam(name, value_array);
        }

        /// <summary>
        /// Sets raw request parameter as multiple values.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <param name="value">List of parameter values.</param>
        private void setRawParam(string name, List<string> value)
        {
            this.p_rawParams[name] = value;
        }

        /// <summary>
        /// Command name.
        /// </summary>
        private string p_command;
        /// <summary>
        /// Request ID.
        /// </summary>
        private string p_requestId;
        /// <summary>
        /// Request type.
        /// </summary>
        private string p_requestType;
        /// <summary>
        /// Dictionary of text parameters.
        /// </summary>
        private Dictionary<string, List<string>> p_textParams;
        /// <summary>
        /// Dictionary of raw parameters.
        /// </summary>
        private Dictionary<string, List<string>> p_rawParams;
        /// <summary>
        /// Request documents.
        /// </summary>
        private Dictionary<string, XmlElement> p_documents;
        /// <summary>
        /// Request XML DOM object.
        /// </summary>
        private XmlDocument p_requestDom;

        /// <summary>
        /// List of available text parameter names.
        /// </summary>
        private static string[] p_textParamNames = {
            "added_external_id",
		    "added_id",
		    "case_sensitive",
		    "cr",
		    "deleted_external_id",
		    "deleted_id",
		    "description",
		    "docs",
		    "exact-match",
		    "facet",
		    "fail_if_exists",
		    "file",
		    "finalize",
		    "for",
		    "force",
		    "from",
		    "full",
		    "group",
		    "group_size",
		    "h",
		    "id",
		    "idif",
		    "iterator_id",
		    "len",
		    "message",
		    "offset",
		    "path",
		    "persistent",
		    "position",
		    "quota",
		    "rate2_ordering",
		    "rate_from",
		    "rate_to",
		    "relevance",
		    "return_internal",
		    "sequence_check",
		    "stem-lang",
		    "step_size",
		    "text",
		    "type"
        };

        /// <summary>
        /// List of available raw parameter names.
        /// </summary>
        private static string[] p_rawParamNames = {
            "query",
		    "list",
		    "ordering"
        };
    }

    /// <summary>
    /// CPS Response class contains single response from CPS storage.
    /// </summary>
    public class CPS_Response
    {
        /// <summary>
        /// Creates new instance of CPS Response class.
        /// </summary>
        /// <param name="connection">CPS_Connection class instance.</param>
        /// <param name="request">CPS_Request class instance.</param>
        /// <param name="responseXml">Raw response XML as string.</param>
        public CPS_Response(CPS_Connection connection, CPS_Request request, string responseXml)
        {
            this.p_simpleXml = new XmlDocument();
            try
            {
                this.p_simpleXml.LoadXml(responseXml);
            }
            catch (Exception)
            {
                throw new CPS_Exception("Received invalid XML response").SetCode(CPS_Exception.ERROR_CODE.INVALID_RESPONSE);
            }

            XmlElement content = null;
            this.p_errors = new List<CPS_SimpleXML>();
            foreach (XmlElement xmle in this.p_simpleXml.DocumentElement.ChildNodes)
            {
                if (xmle.Name == "cps:storage")
                    this.p_storageName = xmle.InnerXml;
                else if (xmle.Name == "cps:command")
                    this.p_command = xmle.InnerXml;
                else if (xmle.Name == "cps:seconds")
                {
                    try
                    {
                        this.p_seconds = float.Parse(xmle.InnerXml, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                    }
                    catch (Exception)
                    {
                        this.p_seconds = 0;
                    }
                }
                else if (xmle.Name == "cps:error")
                {
                    this.p_errors.Add(new CPS_SimpleXML(xmle));
                }
                else if (xmle.Name == "cps:content")
                    content = xmle;
            }

            this.p_textParams = new Dictionary<string, string>();
            this.p_contentArray = null;
            this.p_documents = new Dictionary<string, XmlElement>();
            this.p_facets = new Dictionary<string, Dictionary<string, int>>();
            bool saveDocs = true;
            this.p_words = null;

            if (content != null)
            {
                switch (this.p_command)
                {
                    case "update":
                    case "delete":
                    case "insert":
                    case "partial-replace":
                    case "replace":
                    case "lookup":
                        if (this.p_command != "lookup")
                            saveDocs = false;
                        break;
                    case "search":
                    case "retrieve":
                    case "retrieve-last":
                    case "retrieve-first":
                    case "list-last":
                    case "list-first":
                    case "similar":
                        // In PHP here comes document extraction. In C# document extraction is later, so nothing to do here
                        break;
                    case "alternatives":
                        Dictionary<string, Dictionary<string, CPS_AlternativesResponse.WordInfo>> alt_words = new Dictionary<string, Dictionary<string, CPS_AlternativesResponse.WordInfo>>();
                        foreach (XmlElement xaltlist in content.ChildNodes)
                            foreach (XmlElement xalt in xaltlist.ChildNodes)
                            {
                                if (xalt.Name == "alternatives")
                                {
                                    Dictionary<string, CPS_AlternativesResponse.WordInfo> winfo = new Dictionary<string, CPS_AlternativesResponse.WordInfo>();
                                    XmlElement xto = xalt["to"];
                                    if (xto == null)
                                        continue;

                                    foreach (XmlElement xword in xalt.ChildNodes)
                                    {
                                        if (xword.Name == "word")
                                        {
                                            XmlAttribute xcount = xword.Attributes["count"];
                                            XmlAttribute xcr = xword.Attributes["cr"];
                                            XmlAttribute xidif = xword.Attributes["idif"];
                                            XmlAttribute xh = xword.Attributes["h"];
                                            if (xcount == null || xcr == null || xidif == null || xh == null)
                                                continue;

                                            CPS_AlternativesResponse.WordInfo info = new CPS_AlternativesResponse.WordInfo();
                                            info.word = xword.InnerXml;

                                            try
                                            {
                                                info.count = int.Parse(xcount.Value);
                                                info.cr = float.Parse(xcr.Value, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                                                info.idif = float.Parse(xidif.Value, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                                                info.h = float.Parse(xh.Value, System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
                                            }
                                            catch (Exception)
                                            {
                                                continue;
                                            }

                                            winfo[info.word] = info;
                                        }
                                    }

                                    alt_words[xto.InnerXml] = winfo;
                                }
                            }
                        this.p_words = alt_words;
                        break;
                    case "list-words":
                        Dictionary<string, Dictionary<string, CPS_ListWordsResponse.WordInfo>> list_words = new Dictionary<string, Dictionary<string, CPS_ListWordsResponse.WordInfo>>();
                        foreach (XmlElement xlist in content.ChildNodes)
                        {
                            if (xlist.Name == "list")
                            {
                                Dictionary<string, CPS_ListWordsResponse.WordInfo> winfo = new Dictionary<string, CPS_ListWordsResponse.WordInfo>();
                                XmlAttribute xto = xlist.Attributes["to"];
                                if (xto == null)
                                    continue;

                                foreach (XmlElement xword in xlist.ChildNodes)
                                {
                                    if (xword.Name == "word")
                                    {
                                        XmlAttribute xcount = xword.Attributes["count"];
                                        if (xcount == null)
                                            continue;

                                        CPS_ListWordsResponse.WordInfo info = new CPS_ListWordsResponse.WordInfo();
                                        info.word = xword.InnerXml;

                                        try
                                        {
                                            info.count = int.Parse(xcount.Value);
                                        }
                                        catch (Exception)
                                        {
                                            continue;
                                        }

                                        winfo[info.word] = info;
                                    }
                                }

                                list_words[xto.Value] = winfo;
                            }
                        }
                        this.p_words = list_words;
                        break;
                    case "status":
                    case "list-paths":
                        this.p_contentArray = new CPS_SimpleXML(content);
                        break;
                    default:
                        // nothing special
                        break;
                }

                if (this.p_command == "search" || this.p_command == "list-facets")
                {
                    foreach (XmlElement xmle in content.ChildNodes)
                    {
                        if (xmle.Name == "facet")
                        {
                            XmlAttribute xattr = xmle.Attributes["path"];
                            if (xattr == null || xattr.Value.Length <= 0)
                                continue;

                            string path = xattr.Value;
                            this.p_facets[path] = new Dictionary<string, int>();

                            foreach (XmlElement xmlt in xmle.ChildNodes)
                            {
                                if (xmlt.Name == "term")
                                {
                                    this.p_facets[path][xmlt.InnerXml] = 0;

                                    if (this.p_command == "search")
                                    {
                                        xattr = xmlt.Attributes["count"];
                                        if (xattr != null && xattr.Value.Length > 0)
                                        {
                                            try
                                            {
                                                this.p_facets[path][xmlt.InnerXml] = int.Parse(xattr.Value);
                                            }
                                            catch (Exception)
                                            {
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                foreach (XmlElement xmle in content.ChildNodes)
                {
                    if (Array.Exists<string>(CPS_Response.p_textParamNames, pn => pn == xmle.Name))
                        this.p_textParams[xmle.Name] = xmle.InnerXml;
                    else if (xmle.Name == "results")
                    {
                        foreach (XmlElement xmld in xmle.ChildNodes)
                            this.ProcessRawDocument(connection, xmld, saveDocs);
                    }
                    else if (xmle.Name == connection.getDocumentRootXpath())
                        this.ProcessRawDocument(connection, xmle, saveDocs);
                }
            }
        }

        private void ProcessRawDocument(CPS_Connection connection, XmlElement xmld, bool saveDocs)
        {
            if (xmld.Name == connection.getDocumentRootXpath())
            {
                List<string> idPath = connection.getDocumentIdXpath();
                XmlElement xmlid = xmld;
                int i = 0;
                string id = "";
                for (i = 1; i < idPath.Count; i++)
                {
                    if (xmlid[idPath[i]] != null)
                        xmlid = xmlid[idPath[i]];
                    else
                        break;

                    if (i + 1 == idPath.Count)
                        id = xmlid.InnerXml;
                }

                if (id.Length > 0)
                {
                    if (saveDocs)
                        this.p_documents[id] = xmld;
                    else
                        this.p_documents[id] = null;
                }
            }
        }

        /// <summary>
        /// Gets documents from response, returned type depends on passed returnType parameter.
        /// If returnType is DOC_TYPE_SIMPLEXML, returns Dictionary&lt;string, CPS_SimpleXML&gt;.
        /// If returnType is DOC_TYPE_ARRAY, returns null - not supported yet.
        /// If returnType is DOC_TYPE_STDCLASS, returns Dictionary&lt;string, XmlElement&gt;.
        /// </summary>
        /// <param name="returnType">Defines used return type.</param>
        /// <returns>Documents as Dictionary&lt;string, CPS_SimpleXML&gt; or Dictionary&lt;string, XmlElement&gt;.</returns>
        public Object getRawDocuments(DOC_TYPE returnType)
        {
            if (returnType == DOC_TYPE.DOC_TYPE_SIMPLEXML)
            {
                Dictionary<string, CPS_SimpleXML> ret = new Dictionary<string, CPS_SimpleXML>();

                foreach (KeyValuePair<string, XmlElement> pair in this.p_documents)
                    ret[pair.Key] = new CPS_SimpleXML(pair.Value);

                return ret;
            }
            else if (returnType == DOC_TYPE.DOC_TYPE_ARRAY)
            {
                return null; // not supported yet
            }
            else // DOC_TYPE.DOC_TYPE_STDCLASS
                return this.p_documents;
        }

        /// <summary>
        /// Gets raw facets.
        /// </summary>
        /// <returns>Dictionary with facets.</returns>
        public Dictionary<string, Dictionary<string, int>> getRawFacets()
        {
            return this.p_facets;
        }

        /// <summary>
        /// Returns word information for 'alternatives' and 'list-words' commands.
        /// </summary>
        /// <returns>Word information.</returns>
        public Object getRawWords()
        {
            return this.p_words;
        }

        /// <summary>
        /// Gets response parameter value.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <returns>Parameter value.</returns>
        public string getParam(string name)
        {
            if (Array.Exists<string>(CPS_Response.p_textParamNames, pn => pn == name))
                return this.p_textParams[name];
            else
                throw new CPS_Exception("Invalid response parameter").SetCode(CPS_Exception.ERROR_CODE.INVALID_PARAMETER);
        }

        /// <summary>
        /// Gets response parameter value ar integer.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <returns>Parameter value as integer.</returns>
        public int getParamInt(string name)
        {
            try
            {
                return int.Parse(this.getParam(name));
            }
            catch (CPS_Exception ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                return 0;
            }
        }

        /// <summary>
        /// Gets CPS storage processing time for this response.
        /// </summary>
        /// <returns>Seconds.</returns>
        public float getSeconds()
        {
            return this.p_seconds;
        }

        /// <summary>
        /// Gets response content array for simple commands, like 'status'.
        /// </summary>
        /// <returns>Content array.</returns>
        public CPS_SimpleXML getContentArray()
        {
            return this.p_contentArray;
        }

        /// <summary>
        /// Gets response errors.
        /// </summary>
        /// <returns>List of errors.</returns>
        public List<CPS_SimpleXML> getErrors()
        {
            return this.p_errors;
        }

        /// <summary>
        /// Response XML DOM object.
        /// </summary>
        private XmlDocument p_simpleXml;
        /// <summary>
        /// Storage name.
        /// </summary>
        private string p_storageName;
        /// <summary>
        /// Command name.
        /// </summary>
        private string p_command;
        /// <summary>
        /// Response processing time in seconds.
        /// </summary>
        private float p_seconds;
        /// <summary>
        /// List of errors
        /// </summary>
        private List<CPS_SimpleXML> p_errors;
        /// <summary>
        /// Response documents.
        /// </summary>
        protected Dictionary<string, XmlElement> p_documents;
        /// <summary>
        /// Response facets.
        /// </summary>
        protected Dictionary<string, Dictionary<string, int>> p_facets;
        /// <summary>
        /// Response text parameters.
        /// </summary>
        protected Dictionary<string, string> p_textParams;
        /// <summary>
        /// Response word information.
        /// </summary>
        protected Object p_words;
        /// <summary>
        /// Response content array.
        /// </summary>
        protected CPS_SimpleXML p_contentArray;

        /// <summary>
        /// List of available response text parameter names.
        /// </summary>
        private static string[] p_textParamNames = {
            "hits",
		    "from",
		    "to",
		    "found",
		    "real_query",
		    "iterator_id"
        };

        /// <summary>
        /// Available return document types.
        /// </summary>
        public enum DOC_TYPE
        {
            /// <summary>
            /// PHP's simpleXML-like <see cref="CPS.CPS_SimpleXML"/> class.
            /// </summary>
            DOC_TYPE_SIMPLEXML,
            /// <summary>
            /// Array, not supported yet.
            /// </summary>
            DOC_TYPE_ARRAY,
            /// <summary>
            /// .NET native XML object - <see cref="XmlElement"/>.
            /// </summary>
            DOC_TYPE_STDCLASS
        };
    }

    /// <summary>
    /// CPS SimpleXML class provides simple way to get XML values, very similar to PHP's SimpleXML class.
    /// </summary>
    public class CPS_SimpleXML
    {
        /// <summary>
        /// Creates new CPS SimpleXML class instance from passed XmlElement instance.
        /// </summary>
        /// <param name="element">XmlElement class instance.</param>
        public CPS_SimpleXML(XmlElement element)
        {
            this.p_name = element.Name;
            this.p_values = new List<string>();
            this.p_childs = new Dictionary<string, List<CPS_SimpleXML>>();

            foreach (XmlNode child in element.ChildNodes)
            {
                if (child.NodeType == XmlNodeType.Text)
                    this.p_values.Add(child.Value);
                else if (child.NodeType == XmlNodeType.Element)
                {
                    if (!this.p_childs.ContainsKey(child.Name))
                        this.p_childs[child.Name] = new List<CPS_SimpleXML>();
                    this.p_childs[child.Name].Add(new CPS_SimpleXML((XmlElement)(child)));
                }
            }
        }

        /// <summary>
        /// Gets current tag name.
        /// </summary>
        /// <returns>Tag name.</returns>
        public string GetName()
        {
            return this.p_name;
        }

        /// <summary>
        /// Gets current tag value as string.
        /// </summary>
        /// <param name="seqno">For multiple tags only, tag number.</param>
        /// <returns>String value.</returns>
        public string GetString(int seqno = 0)
        {
            try
            {
                return this.p_values[seqno];
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Gets current tag value as string.
        /// </summary>
        /// <param name="sxml">CPS_SimpleXML class instance.</param>
        /// <returns>String value.</returns>
        public static implicit operator string(CPS_SimpleXML sxml)
        {
            return sxml.GetString();
        }

        /// <summary>
        /// Gets current tag value as integer.
        /// </summary>
        /// <param name="seqno">For multiple tags only, tag number.</param>
        /// <returns>Integer value.</returns>
        public int GetInt(int seqno = 0)
        {
            try
            {
                return int.Parse(this.GetString(seqno));
            }
            catch (Exception)
            {
                return 0;
            }
        }

        /// <summary>
        /// Gets current tag value as integer.
        /// </summary>
        /// <param name="sxml">CPS_SimpleXML class instance.</param>
        /// <returns>Integer value.</returns>
        public static implicit operator int(CPS_SimpleXML sxml)
        {
            return sxml.GetInt();
        }

        /// <summary>
        /// Gets current tag value as float.
        /// </summary>
        /// <param name="seqno">For multiple tags only, tag number.</param>
        /// <returns>Float value.</returns>
        public float GetFloat(int seqno = 0)
        {
            try
            {
                return float.Parse(this.GetString(seqno), System.Globalization.CultureInfo.InvariantCulture.NumberFormat);
            }
            catch (Exception)
            {
                return 0;
            }
        }

        /// <summary>
        /// Gets current tag value as float.
        /// </summary>
        /// <param name="sxml">CPS_SimpleXML class instance.</param>
        /// <returns>Float value.</returns>
        public static implicit operator float(CPS_SimpleXML sxml)
        {
            return sxml.GetFloat();
        }

        /// <summary>
        /// Gets child element by tag name and (in case of multiple tags) tag number.
        /// </summary>
        /// <param name="name">Child name.</param>
        /// <param name="seqno">Tag number.</param>
        /// <returns>Child CPS_SimpleXML element.</returns>
        public CPS_SimpleXML GetChild(string name, int seqno = 0)
        {
            try
            {
                return this.p_childs[name][seqno];
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Gets child element by tag name and (in case of multiple tags) tag number.
        /// </summary>
        /// <param name="name">Child name.</param>
        /// <param name="seqno">Tag number.</param>
        /// <returns>Child CPS_SimpleXML element.</returns>
        public CPS_SimpleXML this[string name, int seqno = 0]
        {
            get
            {
                try
                {
                    return this.p_childs[name][seqno];
                }
                catch (Exception)
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Converts current CPS_SimpleXML instance to XmlElement instance.
        /// </summary>
        /// <param name="parent">Parent XmlElement instance.</param>
        /// <returns>New XmlElement instance.</returns>
        private XmlElement ConvertToXML(XmlElement parent)
        {
            XmlElement ret = (XmlElement)(parent.AppendChild(parent.OwnerDocument.CreateElement(this.p_name)));

            foreach (string value in this.p_values)
                ret.AppendChild(ret.OwnerDocument.CreateTextNode(value));

            foreach (KeyValuePair<string, List<CPS_SimpleXML>> pair in this.p_childs)
                foreach (CPS_SimpleXML child in pair.Value)
                    child.ConvertToXML(ret);

            return ret;
        }

        /// <summary>
        /// Converts current CPS_SimpleXML instance to XmlElement instance.
        /// </summary>
        /// <returns>New XmlElement instance.</returns>
        public XmlElement ConvertToXML()
        {
            XmlDocument doc = new XmlDocument();

            doc.AppendChild(doc.CreateXmlDeclaration("1.0", "utf-8", "yes"));
            XmlElement root = doc.CreateElement("root");
            doc.AppendChild(root);
            
            return this.ConvertToXML(root);
        }

        /// <summary>
        /// Generates string with spaces.
        /// </summary>
        /// <param name="spaces">Number of spaces to generate.</param>
        /// <returns>String with spaces.</returns>
        private string Spaces(int spaces)
        {
            int i = 0;
            string ret = "";

            for (i = 0; i < spaces; i++)
                ret += " ";

            return ret;
        }

        /// <summary>
        /// Dumps CPS_SimpleXML content and structure, very similar to PHP's print_r() function, very usefull for debugging purposes.
        /// Output is recomended to view using fixed-width font, for example Courier New.
        /// </summary>
        /// <param name="spaces">Number of identing spaces.</param>
        /// <returns>Dumped structure.</returns>
        private string Dump(int spaces)
        {
            string ret = "";
            int elems = 0;

            ret += "CPS_SimpleXML(" + this.p_name + ")\r\n";
            ret += this.Spaces(spaces) + "{\r\n";

            foreach (string value in this.p_values)
            {
                if (elems > 0)
                    ret += ",\r\n";
                ret += this.Spaces(spaces + 2) + "\"" + value + "\"";
                elems++;
            }

            foreach (KeyValuePair<string, List<CPS_SimpleXML>> pair in this.p_childs)
                foreach (CPS_SimpleXML child in pair.Value)
                {
                    if (elems > 0)
                        ret += ",\r\n";
                    ret += this.Spaces(spaces + 2) + "[\"" + pair.Key + "\"] => " + child.Dump(spaces + 2);
                    elems++;
                }

            ret += "\r\n" + this.Spaces(spaces) + "}";

            return ret;
        }

        /// <summary>
        /// Dumps CPS_SimpleXML content and structure, very similar to PHP's print_r() function, very usefull for debugging purposes.
        /// Output is recomended to view using fixed-width font, for example Courier New.
        /// </summary>
        /// <returns>Dumped structure.</returns>
        public string Dump()
        {
            return Dump(0);
        }

        /// <summary>
        /// Tag name.
        /// </summary>
        private string p_name;
        /// <summary>
        /// Tag values.
        /// </summary>
        private List<string> p_values;
        /// <summary>
        /// Tag child elements.
        /// </summary>
        private Dictionary<string, List<CPS_SimpleXML>> p_childs;
    }
}
